<?php
	$count=0;
	if(isset($_POST['ssc']))
	{
		$count=$count+1;
	}
	
	if(isset($_POST['hsc']))
	{
		$count=$count+1;
	}
	
	if(isset($_POST['bsc']))
	{
		$count=$count+1;
	}
	
	if(isset($_POST['msc']))
	{
		$count=$count+1;
	}
	
	if ($count<2)
	{
	echo "Select at lest two";
	}
	else
	{
	if(isset($_POST['ssc']))
	{
		echo $_POST['ssc'].' ';
	}
	
	if(isset($_POST['hsc']))
	{
		echo $_POST['hsc'].' ';
	}
	
	if(isset($_POST['bsc']))
	{
		echo $_POST['bsc'].' ';
	}
	
	if(isset($_POST['msc']))
	{
		echo $_POST['msc'].' ';
	}
	}
	
?>
<form action="#" method="POST">
	<fieldset>
		<legend>Gender</legend>
		<form action="check.php" method="POST">
	<fieldset>
		<legend>DEGREE</legend>
		<form action="/action_page.php" method="get">
			  <input type="checkbox" name="ssc" value="ssc"> SSC
			  <input type="checkbox" name="hsc" value="hsc"> HSC
			  <input type="checkbox" name="bsc" value="bsc"> BSc
			  <input type="checkbox" name="msc" value="msc"> MSc
</form> <br/><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>