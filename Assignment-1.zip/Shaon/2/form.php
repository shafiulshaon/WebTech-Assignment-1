
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) 
  {
	 echo "Email is required";
  } 
  elseif(!preg_match("/^[a-zA-Z0-9-_.]+@[a-zA-Z-]+\.[a-zA-Z.]{2,5}$/",$_POST["name"]))
  {
		echo "Emain not valid";
  }
   
  else
  {
		echo $_POST["name"];
  }  
 
}
?>
<form action="#" method="POST">
	<fieldset>
		<legend>EMAIL</legend>
		<input type="text" name="name" value="" >i<br/><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>