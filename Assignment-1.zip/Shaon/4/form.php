<?php
	
	{
	if(empty($_POST['gender']))
		echo "Please select at least one";
	else
		echo $_POST['gender'];
	}
	
?>
<form action="#" method="POST">
	<fieldset>
		<legend>Gender</legend>
		<form>
			  <input type="radio" name="gender" value="male"> Male
			  <input type="radio" name="gender" value="female"> Female
			  <input type="radio" name="gender" value="other"> Other  
</form><br/><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>