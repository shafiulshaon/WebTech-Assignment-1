<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$name = test_input($_POST["name"]);
  if (empty($_POST["name"])) 
  {
	 echo "Name is required";
  } 
  elseif(!preg_match("/^[a-zA-Z ]*$/",$name))
  {
		echo "Only letters and white space allowed";
  }
   
  else
  {
	if (str_word_count($name)<2)
			echo "not 2 words";
	else
		echo $_POST["name"];
  }  
 
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<form action="#" method="POST">
	<fieldset>
		<legend>NAME</legend>
		<input type="text" name="name" value="" ><br/><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>