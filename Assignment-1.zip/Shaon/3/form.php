<?php
	
	if(isset($_POST['dd']) || isset($_POST['mm']) || isset($_POST['yy']))
	{
	if(empty($_POST['dd']) || empty($_POST['mm']) || empty($_POST['yy']))
	echo "invalid format";
	else
	{
		
		{echo $_POST['dd'].'/'.$_POST['mm'].'/'.$_POST['yy'];}
	}
	}
?>

<form action="#" method="POST">
	<fieldset>
		<legend>Date Of Birth</legend>
		<h5>  dd &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
		mm &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp  yy</h5>
		<form action="/action_page.php">
					  <input type="number" name="dd" min="1" max="31"> /
					  <input type="number" name="mm" min="1" max="12"> /
					  <input type="number" name="yyyy" min="1953" max="1998">

					</form><br/><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>