<?php
	
	if($_POST['dd']!=="op"){
	echo $_POST['dd'];	
	}
	else
	echo "must be selected one";
?>


<form action="#" method="post">
	<fieldset>
		<legend>Blood Group</legend>
				
		<select name="dd">
			<option value="op" >option</option>
			<option value="a+" >a+</option>
			<option value="b+" >b+</option>
			<option value="ab+">ab+</option>
			<option value="o+" >o+</option>
		</select>
		<br/><br/>
		
		<input type="submit" name="submit" value="Submit">
		<hr/>
	</fieldset>
</form>